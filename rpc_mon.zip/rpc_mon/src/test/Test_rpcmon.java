package test;
import RpcClient.RpcClient;
import RpcMonitor.RpcMonitorServiceImpl;
import UserServicePkg.UserDO;
import UserServicePkg.UserService;
import UserServicePkg.UserServiceImpl;
import UserServiceServerHandle.UserServiceServer;
import cfg.PublicCfg;
import org.junit.Assert;
import org.junit.Test;
import java.io.IOException;
import java.net.InetSocketAddress;
import static java.lang.Thread.sleep;

/**
 * Created by y00219534 on 2018/12/4.
 */
public class Test_rpcmon extends BaseTest {
    private static final int test_rpc_num = 50;

    public Test_rpcmon() throws IOException {
    }

    @Test
    public void test_allfail(){
        System.out.println("test_allfail start.");
        //关闭UserService
        super.run.stopserver();
        //RPCClient远程调用服务
        RpcClient RpcClient = new RpcClient(new InetSocketAddress("localhost", 8088));
        RpcMonitorServiceImpl rpcmonitor = new RpcMonitorServiceImpl();
        RpcClient.bind(new UserServiceImpl(), rpcmonitor);//绑定Monitor
        UserService service = RpcClient.getProxy(UserService.class);
        for (int i = 0; i < test_rpc_num; i++) {
            Object o = service.getUserById(Long.valueOf(i));
            if(o!=null) {
                UserDO user = (UserDO) o;
                System.out.println("user ID:" + user.getId() + " Name:" + user.getName());
            }
        }
        Assert.assertTrue(rpcmonitor.rpcinfo.getRpc_sum() == test_rpc_num);
        Assert.assertTrue(rpcmonitor.rpcinfo.getRpc_fail_num() == test_rpc_num);
        Assert.assertTrue(rpcmonitor.rpcinfo.getRpc_success_num() == 0);
        rpcmonitor.printStatistic();
    }
    @Test
    public void test_allsuccess(){
        System.out.println("test_allsuccess start.");
        //RPCClient远程调用服务
        RpcClient RpcClient = new RpcClient(new InetSocketAddress(PublicCfg.USER_SERVICE_SERVER_IP, PublicCfg.USER_SERVICE_SERVER_PORT));
        RpcMonitorServiceImpl rpcmonitor = new RpcMonitorServiceImpl();
        RpcClient.bind(new UserServiceImpl(), rpcmonitor);//绑定Monitor
        UserService service = RpcClient.getProxy(UserService.class);
        for (int i = 0; i < test_rpc_num; i++) {
            Object o = service.getUserById(Long.valueOf(i));
            if(o!=null) {
                UserDO user = (UserDO) o;
                System.out.println("user ID:" + user.getId() + " Name:" + user.getName());
            }
        }
        Assert.assertTrue(rpcmonitor.rpcinfo.getRpc_sum() == test_rpc_num);
        Assert.assertTrue(rpcmonitor.rpcinfo.getRpc_success_num() == test_rpc_num);
        Assert.assertTrue(rpcmonitor.rpcinfo.getRpc_fail_num() == 0);
        rpcmonitor.printStatistic();
    }
    @Test
    public void test_random(){
        System.out.println("test_random start.");
        //服务控制
        new Thread(new Runnable() {
            public void run() {
                while(true) {
                    try {
                        int delay = (int) ((Math.random()+0.2)*10000);//0~10000
                        System.out.println("UserService Ctrl delay "+delay+" isRunning "+UserServiceServer.isRunning());
                        sleep(delay);
                        if(UserServiceServer.isRunning() == true ) UserServiceServer.setIsRunning(false);
                        else UserServiceServer.setIsRunning(true);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
        //RPCClient远程调用服务
        RpcClient RpcClient = new RpcClient(new InetSocketAddress("localhost", 8088));
        RpcMonitorServiceImpl rpcmonitor = new RpcMonitorServiceImpl();
        RpcClient.bind(new UserServiceImpl(), rpcmonitor);//绑定Monitor
        UserService service = RpcClient.getProxy(UserService.class);
        for (int i = 0; i < test_rpc_num; i++) {
            Object o = service.getUserById(Long.valueOf(i));
            System.out.printf("rpc No.%d,success:%b.\n",i+1,!rpcmonitor.getRpcinfo().isFailed());
        }
        rpcmonitor.printStatistic();
    }
}
