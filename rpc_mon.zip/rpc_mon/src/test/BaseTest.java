package test;

import RpcMonitorServerHandle.RpcMonitorServerThread;
import UserServiceServerHandle.UserServerThread;
import org.junit.After;
import org.junit.Before;
import java.io.IOException;

/**
 * Created by y00219534 on 2018/12/4.
 */
public class BaseTest {
    UserServerThread run = new UserServerThread();
    Thread ServiceServer = new Thread(run);
    //
    RpcMonitorServerThread run2 = new RpcMonitorServerThread();
    Thread rpcServiceServer = new Thread(run2);

    public BaseTest() throws IOException {
    }

    @Before
    public void before() throws Exception
    {
        //clearData();
        Start_UserService();
        Start_MonitorService();
    }

    @After
    public void after() throws Exception
    {
        clearData();
    }

    protected void clearData() throws Exception
    {
    }
    void Start_UserService(){
        //启用服务 UserServer
        ServiceServer.start();
        System.out.println("UserService started.");
    }
    void Start_MonitorService(){
        //启用Rpcmonitor服务端
        rpcServiceServer.start();
        System.out.println("RpcMonitor Server started.");
    }
}
