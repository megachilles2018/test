package Server;
import java.io.IOException;
/**
 * Created by y00219534 on 2018/12/3.
 */
public interface Server {
    public void stop();

    public void start() throws IOException;

    public void register(Class serviceInterface, Class impl);

    public int getPort();

}
