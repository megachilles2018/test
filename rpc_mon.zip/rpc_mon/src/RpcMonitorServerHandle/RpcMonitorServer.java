package RpcMonitorServerHandle;

import RpcMonitor.RpcInfo;
import Server.Server;
import cfg.PublicCfg;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/**
 * Created by y00219534 on 2018/12/3.
 */
public class RpcMonitorServer implements Server {
    private static ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

    private static final HashMap<String, Class> serviceRegistry = new HashMap<String, Class>();

    private static boolean isRunning = false;

    private static int port;

    public RpcMonitorServer(int port) {
        this.port = port;
    }

    public void stop() {
        isRunning = false;
        executor.shutdown();
    }

    public void start() throws IOException {
        ServerSocket server = new ServerSocket();
        server.bind(new InetSocketAddress(port));
        //System.out.println("RpcMonitorServer start server");
        try {
            while (true) {
                // 1.监听客户端的TCP连接，接到TCP连接后将其封装成task，由线程池执行
                executor.execute(new ServiceTask(server.accept()));
            }
        } finally {
            System.out.println("finally monitor close.");
            server.close();
        }
    }

    public void register(Class serviceInterface, Class impl) {
        serviceRegistry.put(serviceInterface.getName(), impl);
    }

    public boolean isRunning() {
        return isRunning;
    }

    public int getPort() {
        return port;
    }

    private static class ServiceTask implements Runnable {
        Socket clent = null;

        public ServiceTask(Socket client) {
            this.clent = client;
        }

        public void run() {
            ObjectInputStream input = null;
            ObjectOutputStream output = null;
            try {
                input = new ObjectInputStream(clent.getInputStream());
                //readObject()方法必须保证服务端和客户端的RpcInfo包名一致，要不然会出现找不到类的错误
                //System.out.println("客户端发送的对象：" + (RpcInfo) input.readObject());
                RpcInfo rpcinfo = new RpcInfo();
                try {
                    rpcinfo = (RpcInfo)input.readObject();
                } catch (EOFException e){
                }
                //假设将对象信息写入到obj.txt文件中，事先已经在硬盘中建立了一个obj.txt文件
                String filename = PublicCfg.Rpc_monitor_server_write_file_name;
                writeObject(rpcinfo,filename);
                //readObject(filename);

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (output != null) {
                    try {
                        output.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (input != null) {
                    try {
                        input.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (clent != null) {
                    try {
                        clent.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
    }

    //如果在文件中追加对象,每次创建ObjectOutputStream,都会在每次写入时增加header信息.
    //导致读取时出现java.io.StreamCorruptedException: invalid type code: AC异常
    public static <T>void writeObject (T t, String file) throws IOException {

        ObjectOutputStream oos = null;
        try {
            oos = MyOutputStream.newInstance(file);
            oos.writeObject(t);
            oos.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(oos != null) {
                oos.close();
                oos = null;
            }
        }
    }
    //Read to check for debug
    public static void readObject(String filename) throws IOException{
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(new File(filename)));
            RpcInfo rpcinfo = (RpcInfo)ois.readObject();
        }catch(Exception e) {
            e.printStackTrace();
        } finally {
            if(ois != null) {
                ois.close();
                ois = null;
            }
        }
    }
}
