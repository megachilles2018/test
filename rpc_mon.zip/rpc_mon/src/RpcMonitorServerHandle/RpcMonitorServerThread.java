package RpcMonitorServerHandle;

import Server.Server;
import cfg.PublicCfg;
import java.io.IOException;

/**
 * Created by y00219534 on 2018/12/3.
 */
public class RpcMonitorServerThread implements Runnable{

    public void run() {
        try {
            Server serviceServer = new RpcMonitorServer(PublicCfg.RPC_MONITOR_SERVER_PORT);
            serviceServer.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}