package cfg;

/**
 * Created by y00219534 on 2018/12/6.
 */
public class PublicCfg {
    public static final int RPC_MONITOR_SERVER_PORT = 9999;
    public static final int USER_SERVICE_SERVER_PORT = 8088;
    public static final String RPC_MONITOR_SERVER_IP = "127.0.0.1";
    public static final String USER_SERVICE_SERVER_IP = "127.0.0.1";
    public static final String Rpc_monitor_server_write_file_name = "D:\\obj.txt";
}
