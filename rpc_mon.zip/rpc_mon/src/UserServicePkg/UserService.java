package UserServicePkg;

/**
 * Created by y00219534 on 2018/12/3.
 */
public interface UserService {
    public UserDO getUserById(Long id);
    public Long addUser(UserServicePkg.UserDO user);
}
