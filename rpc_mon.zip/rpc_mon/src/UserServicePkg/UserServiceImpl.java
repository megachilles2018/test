package UserServicePkg;
/**
 * Created by y00219534 on 2018/12/3.
 */
public class UserServiceImpl implements UserService{
    public UserServicePkg.UserDO getUserById(Long id) {

        UserServicePkg.UserDO user = new UserServicePkg.UserDO();
        user.setId(System.currentTimeMillis());
        user.setName("name:" + System.currentTimeMillis());

        int waitTime = (int) (Math.random() * 3000);//0~1
        //TODO mock for the cost time of service.. u can rewrite here if u have a good idea...
        try {
            //Thread.sleep(1000*waitTime);
            Thread.sleep(waitTime);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
//        System.out.println("getUserById index:"+id+" ID:"+user.getId()+" Name:"+user.getName());
        return user;
    }

    public Long addUser(UserServicePkg.UserDO user) {
        //TODO mock code for service
        if (user == null) {
            return System.currentTimeMillis();
        }
        return user.getId();
    }
}
