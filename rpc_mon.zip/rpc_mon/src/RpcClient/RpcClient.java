package RpcClient;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.InetSocketAddress;
import java.net.Socket;
/**
 * Created by y00219534 on 2018/12/3.
 */
/**
 * 客户端服务类代理工厂
 *
 * 1. 调用getProxy方法获取代理对象
 * 2. 代理对象的方法被调用时会被invoke方法拦截，执行invoke
 * 	 	1）封装参数，用于发送到服务器，定位服务、执行服务
 * 		2）链接服务器调用服务
 *
 */
public class RpcClient implements InvocationHandler{

    private InetSocketAddress addr;
    private Object Rpcmonitor;
    private Object Rpc;

    public RpcClient(InetSocketAddress addr){
        this.addr = addr;
    }
    /**
     * 生成代理对象
     * @param clazz 代理类型（接口）
     * @return
     */
    @SuppressWarnings("unchecked")
    public <T>T getProxy(Class<T> clazz){
        // clazz不是接口不能使用JDK动态代理
        return (T) Proxy.newProxyInstance(clazz.getClassLoader(), new Class<?>[]{clazz}, RpcClient.this);
    }

    public void bind(Object Rpc, Object Rpcmonitor) {
        this.Rpcmonitor = Rpcmonitor;
        this.Rpc = Rpc;
    }

    public Object invoke(Object obj, Method method, Object[] args) throws Throwable {
        Socket socket = null;
        ObjectOutputStream output = null;
        ObjectInputStream input = null;
        Class clazz = this.Rpcmonitor.getClass();
        //invoke start
        Method start = clazz.getDeclaredMethod("start",null);
        start.invoke(this.Rpcmonitor,null);

        try {
            // 创建Socket客户端，根据指定地址连接远程服务提供者
            socket = new Socket();
            socket.setSoTimeout(1000*10);//设置读操作超时时间30 s
            socket.connect(addr);
            //socket.connect(addr, 1000);//设置连接请求超时时间10 s
            // 将远程服务调用所需的接口类、方法名、参数列表等编码后发送给服务提供者
            output = new ObjectOutputStream(socket.getOutputStream());
            output.writeUTF(method.getDeclaringClass().getName());
            output.writeUTF(method.getName());
            output.writeObject(method.getParameterTypes());
            output.writeObject(args);
            //System.out.println("RpcClient getOutputStream write.");

            // 同步阻塞等待服务器返回应答，获取应答后返回
            input = new ObjectInputStream(socket.getInputStream());
            //System.out.println("RpcClient socket getInputStream.");
            return input.readObject();
        } catch (Throwable e) {
            System.out.println("Rpc failed.");
            Method fail = clazz.getDeclaredMethod("fail",null);
            fail.invoke(this.Rpcmonitor,null);
            return null;
        } finally {
            //System.out.println("finally");
            Method end = clazz.getDeclaredMethod("end",null);
            end.invoke(this.Rpcmonitor,null);
            if (socket != null) socket.close();
            if (output != null) output.close();
            if (input != null) input.close();
        }
    }
}
