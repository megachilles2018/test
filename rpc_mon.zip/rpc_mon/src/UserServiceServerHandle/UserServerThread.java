package UserServiceServerHandle;
import Server.Server;
import UserServicePkg.UserService;
import UserServicePkg.UserServiceImpl;
import cfg.PublicCfg;
import java.io.IOException;

/**
 * Created by y00219534 on 2018/12/3.
 */
public class UserServerThread implements Runnable{
    Server serviceServer = new UserServiceServer(PublicCfg.USER_SERVICE_SERVER_PORT);

    public UserServerThread() throws IOException {
    }
    public void run() {
        try {
            serviceServer.register(UserService.class, UserServiceImpl.class);
            serviceServer.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void stopserver(){
        UserServiceServer.setIsRunning(false);
    }
}
