package RpcMonitor;

import cfg.PublicCfg;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Created by y00219534 on 2018/12/3.
 */
public class RpcMonitorServiceImpl implements RpcMonitorService{
    public RpcInfo rpcinfo = new RpcInfo();
    Long start_time;
    int rpcnum_last_miniute;
    int rpcnum_last_second;
    long last_statistic_m_time;
    long last_statistic_s_time;

    public RpcMonitorServiceImpl() {
        last_statistic_m_time = System.currentTimeMillis();
        last_statistic_s_time = System.currentTimeMillis();
    }

    public RpcInfo getRpcinfo() {
        return rpcinfo;
    }

    public void setRpcinfo(RpcInfo rpcinfo) {
        this.rpcinfo = rpcinfo;
    }

    public Long getStart_time() {
        return start_time;
    }

    public void setStart_time(Long start_time) {
        this.start_time = start_time;
    }

    public int getRpcnum_last_miniute() {
        return rpcnum_last_miniute;
    }

    public void setRpcnum_last_miniute(int rpcnum_last_miniute) {
        this.rpcnum_last_miniute = rpcnum_last_miniute;
    }

    public int getRpcnum_last_second() {
        return rpcnum_last_second;
    }

    public void setRpcnum_last_second(int rpcnum_last_second) {
        this.rpcnum_last_second = rpcnum_last_second;
    }

    public void printStatistic(){
        System.out.println("Rpc Sum:" + rpcinfo.getRpc_sum());
        System.out.println("Rpc success num:" + rpcinfo.getRpc_success_num());
        System.out.println("Rpc fail num:" + rpcinfo.getRpc_fail_num());
        System.out.println("Sum per minute:"+rpcinfo.getSum_per_minute());
        System.out.println("Sum per second:"+rpcinfo.getSum_per_second());
        System.out.println("Rpc average delay:"+rpcinfo.getRpc_avg_delay()+"ms");
        System.out.println("Rpc success rate:"+rpcinfo.getRpc_success_rate());
    }
    @Override
    public void start() {
        start_time = System.currentTimeMillis();
        rpcinfo.setRpc_id(start_time);
        rpcinfo.setFailed(false);
    }

    @Override
    public void fail() {
        rpcinfo.setRpc_fail_num(rpcinfo.getRpc_fail_num() + 1);
        rpcinfo.setFailed(true);
    }

    @Override
    public void end() {
        //System.out.println("RpcMonitor end;");
        rpcinfo.setRpc_sum(rpcinfo.getRpc_sum() + 1);
        rpcinfo.setRpc_delay_millis(System.currentTimeMillis() - start_time);
        if(!rpcinfo.isFailed()) {
            rpcinfo.setRpc_success_num(rpcinfo.getRpc_success_num() + 1);
        }
        rpcinfo.setRpc_success_rate((float)rpcinfo.getRpc_success_num()/(float)rpcinfo.getRpc_sum());
        //
        UpdateStasticCnt();
        //
        DataSendToServer();
    }

    private void UpdateStasticCnt() {
        if(System.currentTimeMillis() - last_statistic_s_time >= 1000){
            rpcinfo.setSum_per_second(rpcinfo.getRpc_sum() - rpcnum_last_second);
            rpcnum_last_second = rpcinfo.getRpc_sum();
            last_statistic_s_time = System.currentTimeMillis();
        }
        if(System.currentTimeMillis() - last_statistic_m_time >= 1000*60){
            rpcinfo.setSum_per_minute(rpcinfo.getRpc_sum() - rpcnum_last_miniute);
            rpcnum_last_miniute = rpcinfo.getRpc_sum();
            last_statistic_m_time = System.currentTimeMillis();
        }
        //成功的才统计延时
        if(!rpcinfo.isFailed()) {
            if (rpcinfo.getRpc_avg_delay() == 0) {
                rpcinfo.setRpc_avg_delay(rpcinfo.getRpc_delay_millis());
            } else {
                if (rpcinfo.getRpc_success_num() != 0) {
                    rpcinfo.setRpc_avg_delay(((rpcinfo.getRpc_success_num() - 1) * rpcinfo.getRpc_avg_delay() + rpcinfo.getRpc_delay_millis()) / rpcinfo.getRpc_success_num());
                }
            }
        }
    }

    private void DataSendToServer() {
        try {
            Socket socket = new Socket(PublicCfg.RPC_MONITOR_SERVER_IP, PublicCfg.RPC_MONITOR_SERVER_PORT);
            // 获取该Socket的输出流，用来向服务器发送信息
            OutputStream os = socket.getOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(os);
            oos.writeObject(rpcinfo);
            socket.shutdownOutput();
            oos.close();
            os.close();
            socket.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    }
