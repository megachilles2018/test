package RpcMonitor;

/**
 * Created by y00219534 on 2018/12/3.
 */
public interface RpcMonitorService {
    void start();
    void fail();
    void end();
}
