package RpcMonitor;
import java.io.Serializable;

/**
 * Created by y00219534 on 2018/12/3.
 */
public class RpcInfo implements Serializable {
    private int rpc_sum;
    private int rpc_success_num;
    private int rpc_fail_num;
    private long rpc_delay_millis;
    private boolean isFailed;
    private long rpc_id;
    private int sum_per_minute;
    private int sum_per_second;
    private long rpc_avg_delay;
    private float rpc_success_rate;

    public float getRpc_success_rate() {
        return rpc_success_rate;
    }

    public void setRpc_success_rate(float rpc_success_rate) {
        this.rpc_success_rate = rpc_success_rate;
    }

    public int getSum_per_minute() {
        return sum_per_minute;
    }

    public void setSum_per_minute(int sum_per_minute) {
        this.sum_per_minute = sum_per_minute;
    }

    public int getSum_per_second() {
        return sum_per_second;
    }

    public void setSum_per_second(int sum_per_second) {
        this.sum_per_second = sum_per_second;
    }

    public long getRpc_avg_delay() {
        return rpc_avg_delay;
    }

    public void setRpc_avg_delay(long rpc_avg_delay) {
        this.rpc_avg_delay = rpc_avg_delay;
    }

    public RpcInfo(){
        this.isFailed = false;
    };

    public long getRpc_id() {
        return rpc_id;
    }

    public void setRpc_id(long rpc_id) {
        this.rpc_id = rpc_id;
    }

    public int getRpc_sum() {
        return rpc_sum;
    }

    public boolean isFailed() {
        return isFailed;
    }

    public void setFailed(boolean failed) {
        isFailed = failed;
    }

    public void setRpc_sum(int rpc_sum) {
        this.rpc_sum = rpc_sum;
    }

    public int getRpc_success_num() {
        return rpc_success_num;
    }

    public void setRpc_success_num(int rpc_success_num) {
        this.rpc_success_num = rpc_success_num;
    }

    public int getRpc_fail_num() {
        return rpc_fail_num;
    }

    public void setRpc_fail_num(int rpc_fail_num) {
        this.rpc_fail_num = rpc_fail_num;
    }

    public long getRpc_delay_millis() {
        return rpc_delay_millis;
    }

    public void setRpc_delay_millis(long rpc_delay_millis) {
        this.rpc_delay_millis = rpc_delay_millis;
    }
}
