import monitor_server.MonitorServer;
import monitor_server.MonitorServerThread;
import monitor_server.RpcStatistic;
import org.junit.After;
import org.junit.Before;

import java.io.File;
import java.util.Map;

import static cfg.PublicCfg.Rpc_monitor_server_write_file_name;

/**
 * Created by y00219534 on 2018/12/4.
 */
public class BaseTest {

    @Before
    public void before()
    {
        clearData();
        Start_MonitorService();
    }

    @After
    public void after()
    {
        readInfo();
        clearData();
    }

    protected void clearData()
    {
        String strPath = Rpc_monitor_server_write_file_name;
        File file = new File(strPath);
        if (file.exists()){
            file.delete();
        }
    }
    void Start_MonitorService(){
        //启用Rpcmonitor服务端
        MonitorServerThread run = new MonitorServerThread();
        Thread monitorserver = new Thread(run);
        monitorserver.start();
        System.out.println("Monitor Server started.");
    }

    void readInfo(){
        //
        for(Map.Entry<String, RpcStatistic> entry: MonitorServer.client_stat_map.entrySet()) {
            System.out.println("monitor:"+entry.getKey());
            System.out.print("Rpc Succ/Fail/Sum:" + entry.getValue().getRpc_success_num() + '/' + entry.getValue().getRpc_fail_num() + '/' + entry.getValue().getRpc_sum());
            System.out.println("(succ rate:" + entry.getValue().getRpc_success_rate() + ").");
            System.out.print(entry.getValue().getSum_per_minute() + " times/min");
            System.out.println("(" + entry.getValue().getSum_per_second() + " times/sec)");
            System.out.println("avg cost:" + entry.getValue().getRpc_avg_delay() + "ms");
        }
        System.out.print("MaxCost:"+MonitorServer.current_max_delay+"ms ");
        MonitorServer.rpc_max_delay.print();
        for (Map.Entry<String,Integer> entry : MonitorServer.method_cnt_map.entrySet()){
            System.out.println("Method:"+entry.getKey()+" cnt:"+entry.getValue());
        }
        MonitorServer.dumpfail(10);
    }
}
