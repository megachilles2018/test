import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import service.UserDO;
import service.UserService;

/**
 * Created by qiguoliang on 2018/11/30
 * <p>
 * <p>
 * </p>
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:spring-bean-test.xml")
public class UserServiceTest extends BaseTest{


    @Autowired
    protected UserService userService;

    @Test
    public void testService() {

        UserDO user = null;
        for (int i = 0; i < 300; i++) {
            user = userService.getUserById(Long.valueOf(i));
            userService.addUser(user);
        }

    }
}
