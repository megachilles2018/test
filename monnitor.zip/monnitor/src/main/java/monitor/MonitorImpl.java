package monitor;

import cfg.PublicCfg;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * Created by y00219534 on 2018/12/10.
 */
@Component("monitor")
@Aspect
public class MonitorImpl {

    RpcInfo rpcinfo = new RpcInfo();
    long start_time;
    int rpcnum_last_miniute;
    int rpcnum_last_second;
    long last_statistic_m_time;
    long last_statistic_s_time;

    @Pointcut(value="execution(* service.UserService.*(..))")
    public void point(){}
    //环绕通知
    @Around(value="point()")
    public Object aroundMethod(ProceedingJoinPoint pjd){
        Object result = null;
        try {
            //前置通知
            rpcinfo.setFailed(false);
            start_time = System.currentTimeMillis();
            rpcinfo.setRpc_id(start_time);
            rpcinfo.setMethod_name(pjd.getSignature().getDeclaringTypeName()+'.'+pjd.getSignature().getName());
            //执行目标方法
            result = pjd.proceed();
            //用新的参数值执行目标方法
            //result = pjd.proceed(new Object[]{"newSpring","newAop"});
            //返回通知
        } catch (Throwable e) {
            //异常通知
            rpcinfo.setRpc_fail_num(rpcinfo.getRpc_fail_num() + 1);
            rpcinfo.setFailed(true);
//            throw new RuntimeException(e);
        }
        //后置通知
        rpcinfo.setRpc_sum(rpcinfo.getRpc_sum() + 1);
        rpcinfo.setRpc_delay_millis(System.currentTimeMillis() - start_time);
        if(!rpcinfo.isFailed()) {
            rpcinfo.setRpc_success_num(rpcinfo.getRpc_success_num() + 1);
        }
        rpcinfo.setRpc_success_rate((float)rpcinfo.getRpc_success_num()/(float)rpcinfo.getRpc_sum());
        //
        UpdateStasticCnt();
        DataSendToServer();
        return result;
    }
    //
    private void UpdateStasticCnt() {

        if(System.currentTimeMillis() - last_statistic_s_time >= 1000){
            //rpcinfo.setSum_per_second(rpcinfo.getRpc_sum() - rpcnum_last_second);
            //rpcnum_last_second = rpcinfo.getRpc_sum();
            rpcinfo.setSum_per_second(0);
            last_statistic_s_time = System.currentTimeMillis();
        }
        if(System.currentTimeMillis() - last_statistic_m_time >= 1000*60){
            //rpcinfo.setSum_per_minute(rpcinfo.getRpc_sum() - rpcnum_last_miniute);
            //rpcnum_last_miniute = rpcinfo.getRpc_sum();
            rpcinfo.setSum_per_minute(0);
            last_statistic_m_time = System.currentTimeMillis();
        }
        rpcinfo.setSum_per_second(rpcinfo.getSum_per_second()+1);
        rpcinfo.setSum_per_minute(rpcinfo.getSum_per_minute()+1);

        //成功的才统计延时
        if(!rpcinfo.isFailed()) {
            if (rpcinfo.getRpc_avg_delay() == 0) {
                rpcinfo.setRpc_avg_delay(rpcinfo.getRpc_delay_millis());
            } else {
                if (rpcinfo.getRpc_success_num() != 0) {
                    rpcinfo.setRpc_avg_delay(((rpcinfo.getRpc_success_num() - 1) * rpcinfo.getRpc_avg_delay() + rpcinfo.getRpc_delay_millis()) / rpcinfo.getRpc_success_num());
                }
            }
        }
    }
    private void DataSendToServer() {
        try {
            Socket socket = new Socket(PublicCfg.RPC_MONITOR_SERVER_IP, PublicCfg.RPC_MONITOR_SERVER_PORT);
            // 获取该Socket的输出流，用来向服务器发送信息
            OutputStream os = socket.getOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(os);
            oos.writeObject(rpcinfo);
            socket.shutdownOutput();
            oos.close();
            os.close();
            socket.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}