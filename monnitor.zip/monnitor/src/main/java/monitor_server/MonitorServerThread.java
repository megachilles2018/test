package monitor_server;

import cfg.PublicCfg;

import java.io.IOException;

/**
 * Created by y00219534 on 2018/12/3.
 */
public class MonitorServerThread implements Runnable{

    public void run() {
        try {
            MonitorServer serviceServer = new MonitorServer(PublicCfg.RPC_MONITOR_SERVER_PORT);
            serviceServer.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}