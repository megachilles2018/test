package monitor_server;

import monitor.RpcInfo;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static cfg.PublicCfg.Rpc_monitor_server_write_file_name;
import static java.lang.Thread.sleep;

/**
 * Created by y00219534 on 2018/12/3.
 */
public class MonitorServer{
    private static ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

    private static final HashMap<String, Class> serviceRegistry = new HashMap<String, Class>();

    private static boolean isRunning = false;

    private static int port;

    public static Map<String,Integer> method_cnt_map = new HashMap<String,Integer>();
    public static Map<String, RpcStatistic> client_stat_map = new HashMap<String, RpcStatistic>();
    public static long current_max_delay = Long.MIN_VALUE;
    public static RpcInfo rpc_max_delay = new RpcInfo();

    public MonitorServer(int port) {
        this.port = port;
    }

    public void stop() {
        isRunning = false;
        executor.shutdown();
    }
    public static void dumpfail(int cnt){
        String strPath = Rpc_monitor_server_write_file_name;
        System.out.println("Failed:"+cnt+" Displayed");
        File file = new File(strPath);
        if (!file.exists()) {
            return;
        }
        try {
            sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(file));
            RpcInfo rpcinfo = null;
            int i=0;
            while(true) {
                try {
                    rpcinfo = (RpcInfo) ois.readObject();
                    if(rpcinfo.isFailed()) {
                        rpcinfo.print();
                        i++;
                    }
                    if(i>cnt-1) break;
                } catch (EOFException ee){
                    break;
                }
                catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(ois!=null) {
                try {
                    ois.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void start() throws IOException {
        ServerSocket server = new ServerSocket();
        server.bind(new InetSocketAddress(port));
        try {
            while (true) {
                // 1.监听客户端的TCP连接，接到TCP连接后将其封装成task，由线程池执行
                executor.execute(new ServiceTask(server.accept()));
            }
        } finally {
            server.close();
        }
    }

    public void register(Class serviceInterface, Class impl) {
        serviceRegistry.put(serviceInterface.getName(), impl);
    }

    public boolean isRunning() {
        return isRunning;
    }

    public int getPort() {
        return port;
    }

    private static class ServiceTask implements Runnable {
        Socket client = null;

        public ServiceTask(Socket client) {
            this.client = client;
        }

        public void run() {
            ObjectInputStream input = null;
            ObjectOutputStream output = null;
            String clientAddr = "";
            try {
                input = new ObjectInputStream(client.getInputStream());
                RpcInfo rpcinfo = new RpcInfo();
                RpcStatistic rpcstat = new RpcStatistic();
                clientAddr = client.getInetAddress().toString();//add IP
                try {
                    rpcinfo = (RpcInfo)input.readObject();
                    if(method_cnt_map.containsKey(clientAddr+"#"+rpcinfo.getMethod_name())) {
                        int value = method_cnt_map.get(clientAddr+"#"+rpcinfo.getMethod_name());
                        method_cnt_map.put(clientAddr+"#"+rpcinfo.getMethod_name(), value + 1);
                    }
                    else {
                        method_cnt_map.put(clientAddr+"#"+rpcinfo.getMethod_name(), 1);
                    }
                    //
                    rpcstat.setSum_per_second(rpcinfo.getSum_per_second());
                    rpcstat.setSum_per_minute(rpcinfo.getSum_per_minute());
                    rpcstat.setRpc_success_rate(rpcinfo.getRpc_success_rate());
                    rpcstat.setRpc_sum(rpcinfo.getRpc_sum());
                    rpcstat.setRpc_avg_delay(rpcinfo.getRpc_avg_delay());
                    rpcstat.setRpc_fail_num(rpcinfo.getRpc_fail_num());
                    rpcstat.setRpc_success_num(rpcinfo.getRpc_success_num());
                    client_stat_map.put(client.getInetAddress().toString(),rpcstat);
                    //
                } catch (EOFException e){
                    e.printStackTrace();
                }
                if(rpcinfo.isFailed()==false){
                    if(rpcinfo.getRpc_delay_millis() > current_max_delay)
                    current_max_delay = rpcinfo.getRpc_delay_millis();
                    rpc_max_delay = rpcinfo;
                }
                rpcinfo.setMethod_name(clientAddr+"#"+rpcinfo.getMethod_name());
                //假设将对象信息写入到obj.txt文件中，事先已经在硬盘中建立了一个obj.txt文件
                String filename = Rpc_monitor_server_write_file_name;
                writeObject(rpcinfo,filename);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (output != null) {
                    try {
                        output.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (input != null) {
                    try {
                        input.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (client != null) {
                    try {
                        client.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
    }
    //如果在文件中追加对象,每次创建ObjectOutputStream,都会在每次写入时增加header信息.
    //导致读取时出现java.io.StreamCorruptedException: invalid type code: AC异常
    public static <T>void writeObject (T t, String file) throws IOException {

        ObjectOutputStream oos = null;
        try {
            oos = MyOutputStream.newInstance(file);
            oos.writeObject(t);
            oos.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if(oos != null) {
                oos.close();
                oos = null;
            }
        }
    }
}
