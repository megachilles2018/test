package monitor_server;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.*;

/**
 * Created by y00219534 on 2018/12/4.
 */

/**
 * 使用自定义的方式,来实现追加写入object
 */
public class MyOutputStream extends ObjectOutputStream {

    public MyOutputStream(OutputStream out) throws IOException {
        super(out);// 会调用writeStreamHeader()
    }

    /**
     * 覆盖父类的方法,使其在已有对象信息并追加时,不写header信息
     * 查看源码会发现:writeStreamHeader方法会写入以下两行内容:
     *
     *  bout.writeShort(STREAM_MAGIC);
     *  bout.writeShort(STREAM_VERSION);
     *
     *  这两行对应的值:
     *  final static short STREAM_MAGIC = (short)0xaced;
     *  final static short STREAM_VERSION = 5;
     *
     *  在文件中头部就会写入:AC ED 00 05
     *  一个文件对象只有在文件头出应该出现此信息,文件内容中不能出现此信息,否则会导致读取错误
     *  所以在追加时,就需要覆盖父类的writeStreamHeader方法,执行reset()方法
     *
     *  reset()方法写入的是这个:final static byte TC_RESET =        (byte)0x79;
     * @throws IOException
     */
    @Override
    protected void writeStreamHeader() throws IOException {
        //super.reset();
    }

    public static ObjectOutputStream newInstance(String file) throws IOException {
        File f = new File(file);
        long length = f.length();
        ObjectOutputStream oos = null;
        if(f.length() == 0) {
            oos = new ObjectOutputStream(new FileOutputStream(new File(file),true));
        } else {
            oos = new MyOutputStream(new FileOutputStream(new File(file),true));
        }
        return oos;
    }
}

