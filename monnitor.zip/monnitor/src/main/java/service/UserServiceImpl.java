package service;

/**
 * Created by qiguoliang on 2018/11/30
 * just for demo
 * <p>
 * <p>
 * </p>
 */
public class UserServiceImpl implements UserService {


    public UserDO getUserById(Long id){

        UserDO user = new UserDO();
        user.setId(System.currentTimeMillis());
        user.setName("name:" + System.currentTimeMillis());
        int waitTime = (int) (Math.random() * 333);
        //TODO mock for the cost time of service.. u can rewrite here if u have a good idea...
        try {
            Thread.sleep(waitTime);
            if(Math.random()>0.795) throw new RuntimeException("Insert error mannually.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return user;
    }

    public Long addUser(UserDO user){
        //TODO mock code for service
        int waitTime = (int) (Math.random() * 333);
        try {
            Thread.sleep(waitTime);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (user == null) {
            return System.currentTimeMillis();
        }
        if(Math.random()>0.77) throw new RuntimeException("Insert error mannually.");
        return user.getId();
    }
}
