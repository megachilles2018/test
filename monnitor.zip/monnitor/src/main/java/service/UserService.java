package service;

/**
 * Created by qiguoliang on 2018/11/30
 * <p>
 * <p>
 * </p>
 */
public interface UserService {

    public UserDO getUserById(Long id);

    public Long addUser(UserDO user);
}
